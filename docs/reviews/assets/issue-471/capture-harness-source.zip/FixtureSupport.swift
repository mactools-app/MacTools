import AppKit
import SwiftUI
import MacToolsPluginKit

// Fixture-only substitutes supply deterministic values to unchanged production views.
// Repair/navigation callbacks intentionally have no external effects.
struct PluginPackageManifest {
    enum UninstallDataPolicy: Equatable { case preserve }
    struct Capabilities: Equatable {}
}

enum SettingsNavigationDestination {
    case marketplaceDetail(MarketplacePluginDetailTarget)
}

@MainActor final class SettingsNavigationCoordinator: ObservableObject {
    func reconcileCurrentDestinationAvailability() {}
    func navigate(to destination: SettingsNavigationDestination) {}
}

@MainActor final class PluginHost: ObservableObject {
    @Published var pluginManagementItems: [PluginManagementItem]
    @Published var pluginMarketplaceOperations: [String: PluginMarketplaceOperation] = [:]
    var cards: [PluginPermissionCard] = []
    let scenario: String
    let runtimeLoaded: Bool
    var didStartInstall = false

    init(scenario: String) throws {
        self.scenario = scenario
        runtimeLoaded = scenario != "runtime-unavailable"
        let data = try Data(contentsOf: Bundle.main.url(forResource: "fixture", withExtension: "json")!)
        let json = try JSONSerialization.jsonObject(with: data) as! [String: Any]
        let metadataData = try JSONSerialization.data(withJSONObject: json)
        let metadata = try JSONDecoder().decode(PluginProductMetadata.self, from: metadataData)
        let localized = (json["localizedMetadata"] as! [String: [String: String]])["en"]!
        let installed = scenario != "installing"
        let item = PluginManagementItem(
            id: "trackpad-gestures", title: localized["displayName"]!, summary: localized["summary"]!,
            version: json["version"] as! String, state: installed ? .installed : .available,
            packageURL: installed ? URL(fileURLWithPath: "/tmp/issue471-fixture/TrackpadGestures.mactoolsplugin") : nil,
            requiresRestartToFullyUnload: false, releaseNotesURL: nil,
            category: "productivity", releaseChannel: "stable", productMetadata: metadata
        )
        pluginManagementItems = [item]
        if installed {
            pluginMarketplaceOperations[item.id] = .init(kind: .install, phase: .completed)
        }
        if scenario == "setup-needed" {
            let stringsData = try Data(contentsOf: Bundle.main.url(forResource: "permission-strings", withExtension: "json")!)
            let strings = try JSONDecoder().decode([String:String].self, from: stringsData)
            cards = ["accessibility", "inputMonitoring"].map { permission in
                PluginPermissionCard(
                    id: "trackpad-gestures.permission.\(permission)", pluginID: "trackpad-gestures", permissionID: permission,
                    title: strings["permission.\(permission).title"]!,
                    description: strings["permission.\(permission).description"]!,
                    iconSystemImage: permission == "accessibility" ? "accessibility" : "keyboard.badge.eye",
                    statusText: AppL10n.plugins("plugin.permission.notGranted", defaultValue: "未授权"),
                    statusSystemImage: "exclamationmark.triangle.fill", statusTone: .caution,
                    footnote: strings["permission.\(permission).footnote"]!,
                    buttonTitle: AppL10n.plugins("plugin.permission.openAuthorization", defaultValue: "前往授权")
                )
            }
        }
    }

    func hasPluginSettings(pluginID: String) -> Bool { runtimeLoaded && scenario != "installing" }
    func presentPluginSettings(pluginID: String) {}
    func uninstallDynamicPlugin(pluginID: String) throws {}
    func recheckPluginRequirements() {}
    func performPermissionAction(pluginID: String, permissionID: String, sourceFrame: CGRect?) {}
    func marketplaceSetupPresentation(pluginID: String) -> MarketplacePluginSetupPresentation? {
        guard let item = pluginManagementItems.first(where: { $0.id == pluginID }) else { return nil }
        return .init(item: item, missingPermissionCards: cards,
                     isRuntimeLoaded: runtimeLoaded && scenario != "installing",
                     hasSettings: hasPluginSettings(pluginID: pluginID))
    }
    func installPluginFromCatalog(pluginID: String) async throws {
        didStartInstall = true
        pluginMarketplaceOperations[pluginID] = .init(kind: .install, phase: .running)
        // Suspend the fixture operation; no package download, permission check or preferences write.
        try await Task.sleep(for: .seconds(3600))
    }
    func updatePluginFromCatalog(pluginID: String) async throws {
        try await installPluginFromCatalog(pluginID: pluginID)
    }
}

func permissionGuidanceSourceFrame(eventType: NSEvent.EventType?, mouseLocation: CGPoint) -> CGRect? { nil }
