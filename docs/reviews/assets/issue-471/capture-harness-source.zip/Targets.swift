import Foundation

struct MarketplacePluginDetailTarget: Hashable {
    let pluginID: String
    let providerID: String?
    let actionID: String?

    init(pluginID: String, providerID: String? = nil, actionID: String? = nil) {
        self.pluginID = pluginID
        self.providerID = providerID
        self.actionID = actionID
    }

    var actionHighlight: MarketplacePluginActionHighlight? {
        guard let providerID, let actionID else { return nil }
        return MarketplacePluginActionHighlight(providerID: providerID, actionID: actionID)
    }
}

struct MarketplacePluginActionHighlight: Hashable {
    let providerID: String
    let actionID: String
}
