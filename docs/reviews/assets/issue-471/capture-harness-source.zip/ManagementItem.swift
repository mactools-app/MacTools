import Foundation
import MacToolsPluginKit

struct PluginManagementItem: Identifiable, Equatable {
    enum State: Equatable {
        case available
        case localDevelopment
        case installed
        case updateAvailable(installedVersion: String, catalogVersion: String)
        case restartRequired
        case failed(String)
        case incompatible(String)
        case revoked(String?)
    }

    let id: String
    let title: String
    let summary: String?
    let version: String
    let state: State
    let packageURL: URL?
    let requiresRestartToFullyUnload: Bool
    let releaseNotesURL: URL?
    let category: String?
    let releaseChannel: String?
    let capabilities: PluginPackageManifest.Capabilities?
    let uninstallDataPolicy: PluginPackageManifest.UninstallDataPolicy
    let productMetadata: PluginProductMetadata?

    var productSearchKeywords: [String] {
        productMetadata?.searchKeywords ?? []
    }

    init(
        id: String,
        title: String,
        summary: String?,
        version: String,
        state: State,
        packageURL: URL?,
        requiresRestartToFullyUnload: Bool,
        releaseNotesURL: URL?,
        category: String? = nil,
        releaseChannel: String? = nil,
        capabilities: PluginPackageManifest.Capabilities? = nil,
        uninstallDataPolicy: PluginPackageManifest.UninstallDataPolicy = .preserve,
        productMetadata: PluginProductMetadata? = nil
    ) {
        self.id = id
        self.title = title
        self.summary = summary
        self.version = version
        self.state = state
        self.packageURL = packageURL
        self.requiresRestartToFullyUnload = requiresRestartToFullyUnload
        self.releaseNotesURL = releaseNotesURL
        self.category = category
        self.releaseChannel = releaseChannel
        self.capabilities = capabilities
        self.uninstallDataPolicy = uninstallDataPolicy
        self.productMetadata = productMetadata
    }

    var statusText: String {
        switch state {
        case .available:
            return AppL10n.plugins("plugin.status.available", defaultValue: "可安装")
        case .localDevelopment:
            return AppL10n.plugins("plugin.status.localDevelopment", defaultValue: "本地开发")
        case .installed:
            return AppL10n.plugins("plugin.status.installed", defaultValue: "已安装")
        case .updateAvailable:
            return AppL10n.plugins("plugin.status.updateAvailable", defaultValue: "可更新")
        case .restartRequired:
            return AppL10n.plugins("plugin.status.restartRequired", defaultValue: "需重启")
        case .failed:
            return AppL10n.plugins("plugin.status.failed", defaultValue: "加载失败")
        case .incompatible:
            return AppL10n.plugins("plugin.status.incompatible", defaultValue: "不兼容")
        case .revoked:
            return AppL10n.plugins("plugin.status.revoked", defaultValue: "已撤回")
        }
    }

    var detailText: String {
        switch state {
        case .available:
            return summary ?? AppL10n.plugins("plugin.detail.available", defaultValue: "可以安装此插件。")
        case .localDevelopment:
            return summary ?? AppL10n.plugins("plugin.detail.localDevelopment", defaultValue: "来自本地开发插件列表。")
        case .installed:
            if requiresRestartToFullyUnload {
                return AppL10n.plugins("plugin.detail.restartRequiredAfterUpdate", defaultValue: "新版本将在重启后启用，旧代码将在重启后彻底释放。")
            }

            return summary ?? ""
        case let .updateAvailable(installedVersion, catalogVersion):
            return AppL10n.pluginsFormat(
                "plugin.detail.updateAvailableFormat",
                defaultValue: "已安装 %@，可更新到 %@。",
                installedVersion,
                catalogVersion
            )
        case .restartRequired:
            return AppL10n.plugins("plugin.detail.restartRequiredAfterUpdate", defaultValue: "新版本将在重启后启用，旧代码将在重启后彻底释放。")
        case let .failed(reason), let .incompatible(reason):
            return reason
        case let .revoked(reason):
            return reason ?? AppL10n.plugins("plugin.detail.revoked", defaultValue: "此版本已被撤回。")
        }
    }

    var canInstall: Bool {
        switch state {
        case .available, .localDevelopment:
            return true
        default:
            return false
        }
    }

    var canUpdate: Bool {
        if case .updateAvailable = state {
            return true
        }

        return false
    }

    var canUninstall: Bool {
        switch state {
        case .installed, .updateAvailable, .restartRequired, .failed, .incompatible, .revoked:
            return packageURL != nil
        case .available, .localDevelopment:
            return false
        }
    }
}
