from pathlib import Path
import sys, subprocess, json, shutil
root = Path('/Users/yihong/.codex/worktrees/c755/MacTools')
base = Path('/tmp/mactools-471-screenshots/harness')
sys.path.insert(0, str(root/'scripts/plugins'))
from plugin_source_manifest import expand_localized_references
manifestPath = root/'Plugins/TrackpadGestures/plugin.json'
manifest = expand_localized_references(json.loads(manifestPath.read_text()), manifestPath)
(base/'fixture.json').write_text(json.dumps(manifest, indent=2))
pluginStrings = json.loads((root/'Plugins/TrackpadGestures/Resources/Localizable.xcstrings').read_text())['strings']
cardStrings = {}
for prefix in ['accessibility', 'inputMonitoring']:
    for field in ['title', 'description', 'footnote']:
        key = f'permission.{prefix}.{field}'
        cardStrings[key] = pluginStrings[key]['localizations']['en']['stringUnit']['value']
(base/'permission-strings.json').write_text(json.dumps(cardStrings, indent=2))
(base/'BeforeView.swift').write_text(subprocess.check_output(['git', 'show', 'origin/main:Sources/App/MarketplacePluginDetailView.swift'], cwd=root).decode())
shutil.copyfile(root/'Sources/App/MarketplacePluginDetailView.swift', base/'AfterView.swift')
shutil.copyfile(root/'Sources/App/MarketplacePluginSetupPresentation.swift', base/'SetupPresentation.swift')
shutil.copyfile(root/'Sources/Core/Plugins/PluginMarketplaceOperation.swift', base/'MarketplaceOperation.swift')
shutil.copyfile(root/'Sources/App/AppL10n.swift', base/'AppL10n.swift')
shutil.copyfile(root/'Sources/Core/Plugins/Dynamic/PluginProductMetadata.swift', base/'ProductMetadata.swift')
manager = (root/'Sources/Core/Plugins/Dynamic/DynamicPluginManager.swift').read_text()
start = manager.index('struct PluginManagementItem:')
end = manager.index('\nstruct PluginPackageUpdateFailure', start)
(base/'ManagementItem.swift').write_text('import Foundation\nimport MacToolsPluginKit\n\n'+manager[start:end])
settings = (root/'Sources/App/SettingsView.swift').read_text()
start = settings.index('struct PermissionSettingsRow:')
end = settings.index('\nprivate struct PermissionCenterSettingsView', start)
row = settings[start:end]
start = settings.index('func statusColor(for tone:')
end = settings.index('\nstruct AboutSettingsView', start)
status = settings[start:end]
(base/'PermissionRow.swift').write_text('import SwiftUI\nimport MacToolsPluginKit\n\n'+row+'\n'+status)
nav = (root/'Sources/App/SettingsNavigationCoordinator.swift').read_text()
start = nav.index('struct MarketplacePluginDetailTarget:')
end = nav.index('\nextension SettingsNavigationDestination', start)
(base/'Targets.swift').write_text('import Foundation\n\n'+nav[start:end])
for phase in ['before', 'after']:
    app = base/f'{phase}.app'
    resources = app/'Contents/Resources'
    (app/'Contents/MacOS').mkdir(parents=True, exist_ok=True)
    resources.mkdir(parents=True, exist_ok=True)
    for source in ['fixture.json', 'permission-strings.json']:
        shutil.copyfile(base/source, resources/source)
    en = resources/'en.lproj'
    en.mkdir(exist_ok=True)
    strings = json.loads((root/'Sources/Resources/Localization/Plugins.xcstrings').read_text())['strings']
    def escape(v): return v.replace('\\','\\\\').replace('"','\\"').replace('\n','\\n')
    output = []
    for key,value in strings.items():
        unit = value.get('localizations',{}).get('en',{}).get('stringUnit',{})
        if 'value' in unit: output.append(f'"{escape(key)}" = "{escape(unit["value"])}";')
    (en/'Plugins.strings').write_text('\n'.join(output))
    shutil.copyfile(root/'build/DerivedDataTests/Build/Products/Debug/MacTools Dev.app/Contents/Resources/en.lproj/Settings.strings', en/'Settings.strings')
    (app/'Contents/Info.plist').write_text(f'''<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"><plist version="1.0"><dict><key>CFBundleExecutable</key><string>capture</string><key>CFBundleIdentifier</key><string>local.mactools.issue471.capture.{phase}</string><key>CFBundleName</key><string>Issue 471 Fixture</string><key>CFBundleDevelopmentRegion</key><string>en</string><key>NSHighResolutionCapable</key><true/></dict></plist>''')
print('Prepared exact view sources, production models/renderer, and resolved manifest fixture')
