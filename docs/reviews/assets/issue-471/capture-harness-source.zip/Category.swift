import Foundation
import SwiftUI
import MacToolsPluginKit

enum PluginCategory: String, CaseIterable, Hashable, Identifiable {
    case display
    case audio
    case system
    case storage
    case productivity
    case monitoring
    case other

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .display: return AppL10n.plugins("plugin.category.display", defaultValue: "显示")
        case .audio: return AppL10n.plugins("plugin.category.audio", defaultValue: "音频")
        case .system: return AppL10n.plugins("plugin.category.system", defaultValue: "系统")
        case .storage: return AppL10n.plugins("plugin.category.storage", defaultValue: "清理")
        case .productivity: return AppL10n.plugins("plugin.category.productivity", defaultValue: "效率")
        case .monitoring: return AppL10n.plugins("plugin.category.monitoring", defaultValue: "监控")
        case .other: return AppL10n.plugins("plugin.category.other", defaultValue: "其他")
        }
    }

    var iconName: String {
        switch self {
        case .display: return "display"
        case .audio: return "speaker.wave.2"
        case .system: return "cpu"
        case .storage: return "internaldrive"
        case .productivity: return "wand.and.rays"
        case .monitoring: return "chart.line.uptrend.xyaxis"
        case .other: return "square.grid.2x2"
        }
    }

    var iconTint: Color {
        switch self {
        case .display: return .blue
        case .audio: return .purple
        case .system: return .gray
        case .storage: return .orange
        case .productivity: return .green
        case .monitoring: return .pink
        case .other: return .secondary
        }
    }

    var order: Int {
        switch self {
        case .display: return 0
        case .audio: return 1
        case .system: return 2
        case .storage: return 3
        case .productivity: return 4
        case .monitoring: return 5
        case .other: return 100
        }
    }

    static var orderedCases: [PluginCategory] {
        allCases.sorted { $0.order < $1.order }
    }

    init(rawString: String?) {
        guard
            let rawString,
            let value = PluginCategory(rawValue: rawString.trimmingCharacters(in: .whitespacesAndNewlines).lowercased())
        else {
            self = .other
            return
        }

        self = value
    }
}
