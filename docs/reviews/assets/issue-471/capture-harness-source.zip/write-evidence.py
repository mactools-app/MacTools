from pathlib import Path
import hashlib,json,subprocess,datetime,zipfile
root=Path('/Users/yihong/.codex/worktrees/c755/MacTools')
base=Path('/tmp/mactools-471-screenshots')
h=base/'harness'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=subprocess.check_output(['git','rev-parse','origin/main'],cwd=root).decode().strip()
source_file='Sources/App/MarketplacePluginDetailView.swift'
before=subprocess.check_output(['git','show',f'{baseline}:{source_file}'],cwd=root)
assert before==(h/'BeforeView.swift').read_bytes()
assert (root/source_file).read_bytes()==(h/'AfterView.swift').read_bytes()
assert (root/'Sources/App/MarketplacePluginSetupPresentation.swift').read_bytes()==(h/'SetupPresentation.swift').read_bytes()
strings=json.loads((root/'Sources/Resources/Localization/Plugins.xcstrings').read_text())['strings']
def escape(v): return v.replace('\\','\\\\').replace('"','\\"').replace('\n','\\n')
output=[]
for key,value in strings.items():
 unit=value.get('localizations',{}).get('en',{}).get('stringUnit',{})
 if 'value' in unit:output.append(f'"{escape(key)}" = "{escape(unit["value"])}";')
assert '\n'.join(output)==(h/'after.app/Contents/Resources/en.lproj/Plugins.strings').read_text()
scenarios={
 'installing':{'management_state':'available','package_url':None,'runtime_loaded':False,'settings_available':False,'operation_kind':'install','operation_phase':'running','interaction':'Deliver NSEvent mouse down/up to fixture window Install button; require didStartInstall == true before saving. Original before view sets its own activeOperation @State. After view reads host operation snapshot. Fixture async operation suspends and never downloads a package.'},
 'setup-needed':{'management_state':'installed','package_url':'/tmp/issue471-fixture/TrackpadGestures.mactoolsplugin (synthetic path; never read or written)','runtime_loaded':True,'settings_available':True,'operation_kind':'install','operation_phase':'completed','missing_permissions':['accessibility','inputMonitoring'],'interaction':'Deterministic installed/loaded fixture, with both permissions marked ungranted. Permission cards use actual TrackpadGestures English requirement descriptions/footnotes and host icon/button conventions. No repair buttons invoked.'}
}
images=[]
for phase in ['before','after']:
 for scenario in scenarios:
  p=base/f'{phase}-{scenario}.png'
  images.append({'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p),'width_px':1800,'height_px':1520,'phase':phase,'scenario':scenario,'rendered_view_source_sha256':sha(h/('BeforeView.swift' if phase=='before' else 'AfterView.swift')),'executable_sha256':sha(h/f'{phase}.app/Contents/MacOS/capture')})
shared=[]
for name,source,extraction in [
 ('AppL10n.swift','Sources/App/AppL10n.swift','whole file'),
 ('ProductMetadata.swift','Sources/Core/Plugins/Dynamic/PluginProductMetadata.swift','whole file'),
 ('ManagementItem.swift','Sources/Core/Plugins/Dynamic/DynamicPluginManager.swift','PluginManagementItem struct only'),
 ('PermissionRow.swift','Sources/App/SettingsView.swift','PermissionSettingsRow and statusColor only'),
 ('Targets.swift','Sources/App/SettingsNavigationCoordinator.swift','MarketplacePluginDetailTarget and MarketplacePluginActionHighlight only'),
 ('SetupPresentation.swift','Sources/App/MarketplacePluginSetupPresentation.swift','whole file'),
 ('MarketplaceOperation.swift','Sources/Core/Plugins/PluginMarketplaceOperation.swift','whole file'),
 ('Category.swift','Sources/Core/Plugins/PluginCategory.swift','PluginCategory enum only'),
 ('DetailCopy.swift','Sources/App/MarketplacePluginDetailCopy.swift','whole file (baseline matches current)')]:
 shared.append({'source':source,'extraction':extraction,'captured_source_sha256':sha(h/name)})
framework=root/'build/DerivedDataTests/Build/Products/Debug/MacToolsPluginKit.framework/Versions/A/MacToolsPluginKit'
evidence={
 'issue':'https://github.com/mactools-app/MacTools/issues/471',
 'captured_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'before_baseline_commit':baseline,
 'before_view':'Unmodified git show origin/main:Sources/App/MarketplacePluginDetailView.swift',
 'after_view':'Unmodified final merged working-tree Sources/App/MarketplacePluginDetailView.swift',
 'capture_method':'Native macOS SwiftUI/AppKit rendering in isolated NSHostingView inside a temporary fixture NSWindow. Save bitmapImageRepForCachingDisplay/cacheDisplay as PNG. No generative imaging, compositing, retouching, cropping, or resized deliverables.',
 'native_rendering_environment':{'macOS':'27.2 (26B5101f)','architecture':'arm64','swift':'Apple Swift 6.4','appearance':'Aqua/light','locale':'en','content_width_pt':900,'content_height_pt':760,'pixel_scale':2,'framework':str(framework),'framework_sha256':sha(framework)},
 'catalog_fixture':{'source':'Plugins/TrackpadGestures/plugin.json','version':'2.0.1','projection':'scripts/plugins/plugin_source_manifest.py expand_localized_references','resolved_fixture_sha256':sha(h/'fixture.json'),'permission_copy_source':'Plugins/TrackpadGestures/Resources/Localizable.xcstrings English strings','permission_copy_sha256':sha(h/'permission-strings.json')},
 'localization':'Both before and after use identical English Plugins.strings generated from the final localization catalog. The before view does not consume the added operation/setup-status keys. PluginRuntimeLocalization.source.setPreference("en") changes only the process locale snapshot; no preferences are saved.',
 'localization_resource_sha256':sha(h/'after.app/Contents/Resources/en.lproj/Plugins.strings'),
 'shared_production_source':shared,
 'fixture_scenarios':scenarios,
 'fixture_substitutes':['PluginHost with deterministic management, operation, runtime, settings, and permission snapshots','SettingsNavigationCoordinator with inert navigation callbacks','Minimal PluginPackageManifest nested type substitutes required by PluginManagementItem; these fields are unused by rendering','permissionGuidanceSourceFrame inert substitute, unused because repair buttons are not pressed'],
 'suppressed_external_effects':['No real plugin installation or download','No TCC permission checks or permission prompts','No plugin action execution','No System Settings opening','No real MacTools app launch or app preference writes','No global input events: installation clicks are delivered directly into the fixture window'],
 'limitations':['These are genuine native renderings of the exact detail view with deterministic fixture data, not screenshots of a real completed catalog download or the whole Settings window.','Fixture lifecycle/navigation/permission callbacks do not validate the actual host side effects.','Captures cover light appearance in English on macOS 27.2; keyboard navigation, VoiceOver, hardware permissions, macOS 14 appearance, and Search routing are not established by these PNGs.'],
 'generation_commands':[
  'python3 /tmp/mactools-471-screenshots/harness/prepare.py',
  'For each phase: xcrun swiftc -swift-version 6 -module-cache-path /tmp/mactools-471-screenshots/harness/module-cache -target arm64-apple-macos14.0 -F build/DerivedDataTests/Build/Products/Debug -framework MacToolsPluginKit -Xlinker -rpath -Xlinker <repo>/build/DerivedDataTests/Build/Products/Debug <harness>/{BeforeView|AfterView}.swift <harness>/{FixtureSupport,ManagementItem,ProductMetadata,AppL10n,Targets,PermissionRow,SetupPresentation,MarketplaceOperation,Category,DetailCopy,CaptureMain}.swift -o <harness>/{before|after}.app/Contents/MacOS/capture',
  'For each phase and scenario: /tmp/mactools-471-screenshots/harness/{before|after}.app/Contents/MacOS/capture {installing|setup-needed} /tmp/mactools-471-screenshots/{before|after}-{installing|setup-needed}.png'
 ],
 'temporary_harness_source_archive':'/tmp/mactools-471-screenshots/capture-harness-source.zip',
 'images':images
}
(base/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
with zipfile.ZipFile(base/'capture-harness-source.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(h.iterdir()):
  if p.is_file() and p.suffix in ['.swift','.py','.json']:
   z.write(p,arcname=p.name)
print(json.dumps({'output':str(base),'images':[{ 'file':i['file'],'bytes':i['bytes']} for i in images],'evidence_bytes':(base/'evidence.json').stat().st_size,'harness_archive_bytes':(base/'capture-harness-source.zip').stat().st_size},indent=2))
