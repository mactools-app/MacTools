import AppKit
import SwiftUI
import MacToolsPluginKit

@MainActor
func pressInstall(in window: NSWindow) {
    let location = NSPoint(x: 835, y: 716)
    let up = NSEvent.mouseEvent(with: .leftMouseUp, location: location,
                               modifierFlags: [], timestamp: ProcessInfo.processInfo.systemUptime + 0.02,
                               windowNumber: window.windowNumber, context: nil,
                               eventNumber: 2, clickCount: 1, pressure: 0)!
    let down = NSEvent.mouseEvent(with: .leftMouseDown, location: location,
                                 modifierFlags: [], timestamp: ProcessInfo.processInfo.systemUptime,
                                 windowNumber: window.windowNumber, context: nil,
                                 eventNumber: 1, clickCount: 1, pressure: 1)!
    NSApp.postEvent(up, atStart: true)
    NSApp.sendEvent(down)
}

@main
struct CaptureMain {
    @MainActor static func main() throws {
        let arguments = CommandLine.arguments
        let scenario = arguments[1]
        let outputURL = URL(fileURLWithPath: arguments[2])
        PluginRuntimeLocalization.source.setPreference("en")
        let application = NSApplication.shared
        application.setActivationPolicy(.accessory)
        application.appearance = NSAppearance(named: .aqua)
        let host = try PluginHost(scenario: scenario)
        let navigation = SettingsNavigationCoordinator()
        let root = MarketplacePluginDetailView(
            pluginHost: host, navigationCoordinator: navigation,
            target: .init(pluginID: "trackpad-gestures")
        )
        .preferredColorScheme(.light)
        .frame(width: 900, height: 760)
        .background(Color(nsColor: .windowBackgroundColor))
        let view = NSHostingView(rootView: root)
        view.frame = NSRect(x: 0, y: 0, width: 900, height: 760)
        let window = NSWindow(contentRect: view.frame, styleMask: [.borderless], backing: .buffered, defer: false)
        window.contentView = view
        window.appearance = NSAppearance(named: .aqua)
        window.setFrameOrigin(NSPoint(x: 100, y: 100))
        window.orderFrontRegardless()
        window.makeKey()
        view.layoutSubtreeIfNeeded()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            if scenario == "installing" {
                pressInstall(in: window)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                if scenario == "installing" && !host.didStartInstall {
                    fputs("Fixture Install was not invoked\n", stderr)
                    exit(3)
                }
                view.layoutSubtreeIfNeeded()
                view.displayIfNeeded()
                guard let bitmap = view.bitmapImageRepForCachingDisplay(in: view.bounds) else { exit(4) }
                view.cacheDisplay(in: view.bounds, to: bitmap)
                guard let png = bitmap.representation(using: .png, properties: [:]) else { exit(5) }
                try! png.write(to: outputURL)
                print("Captured \(scenario): \(bitmap.pixelsWide)x\(bitmap.pixelsHigh), installInvoked=\(host.didStartInstall)")
                window.orderOut(nil)
                application.terminate(nil)
            }
        }
        application.run()
    }
}
